import os
import sys

sys.path.insert(0, os.path.join(os.getcwd(), "Project_Sistem_Kartu"))
import main


def run_all():
    print("Processing all images in input folder...")
    main.process_all_in_input()
    print("Creating collage (if 4 images available)...")
    main.create_daily_collage()


if __name__ == "__main__":
    run_all()
