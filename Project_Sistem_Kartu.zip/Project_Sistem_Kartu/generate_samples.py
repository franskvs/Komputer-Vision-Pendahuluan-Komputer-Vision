import os
import cv2
import numpy as np
import config


def make_samples(n=5):
    od = os.path.join(os.getcwd(), "Project_Sistem_Kartu", "input")
    os.makedirs(od, exist_ok=True)
    for i in range(1, n+1):
        img = np.ones((config.CARD_HEIGHT, config.CARD_WIDTH, 3), dtype=np.uint8) * 255
        color = (int(50*i) % 255, int(80*i) % 255, int(120*i) % 255)
        cv2.rectangle(img, (10, 10), (config.CARD_WIDTH-10, config.CARD_HEIGHT-10), color, -1)
        cv2.putText(img, f"Sample {i}", (20, config.CARD_HEIGHT//2), cv2.FONT_HERSHEY_SIMPLEX, 1.0, (255,255,255), 2)
        path = os.path.join(od, f"sample_{i}.jpg")
        cv2.imwrite(path, img)
        print("Wrote", path)


if __name__ == "__main__":
    make_samples(5)
