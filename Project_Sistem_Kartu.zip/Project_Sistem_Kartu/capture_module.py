import os
import cv2
import platform


def load_image(path: str):
    if not os.path.exists(path):
        raise FileNotFoundError(f"File not found: {path}")
    img = cv2.imread(path)
    if img is None:
        raise ValueError(f"Unable to read image: {path}")
    return img


def _open_capture(index: int = 0):
    system = platform.system()
    # On Windows, DirectShow backend often works better
    if system == "Windows":
        cap = cv2.VideoCapture(index, cv2.CAP_DSHOW)
        if cap.isOpened():
            return cap
    # Fallback to default
    cap = cv2.VideoCapture(index)
    return cap


def capture_from_webcam(index: int = 0, preview: bool = True):
    cap = _open_capture(index)
    if not cap.isOpened():
        cap.release()
        raise RuntimeError("Webcam not available")

    if preview:
        win_name = "Webcam - press SPACE to capture, ESC to cancel"
        cv2.namedWindow(win_name, cv2.WINDOW_NORMAL)
        while True:
            ret, frame = cap.read()
            if not ret:
                break
            cv2.imshow(win_name, frame)
            key = cv2.waitKey(1) & 0xFF
            # SPACE to capture
            if key == 32:
                cv2.destroyWindow(win_name)
                cap.release()
                return frame
            # ESC to cancel
            if key == 27:
                cv2.destroyWindow(win_name)
                cap.release()
                return None
        cv2.destroyWindow(win_name)
        cap.release()
        raise RuntimeError("Failed to read from webcam")
    else:
        ret, frame = cap.read()
        cap.release()
        if not ret or frame is None:
            raise RuntimeError("Failed to capture image from webcam")
        return frame

