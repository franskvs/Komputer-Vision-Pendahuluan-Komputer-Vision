CARD_WIDTH = 400
CARD_HEIGHT = 250
OUTPUT_QUALITY = 95
WATERMARK_TEXT = "SmartAttend v1.0"
BASE_OUTPUT = "Project_Sistem_Kartu/output"
INPUT_DIR = "Project_Sistem_Kartu/input"
