import os
from datetime import datetime
import cv2
import config


def ensure_dir(path: str):
    os.makedirs(path, exist_ok=True)


def save_with_organization(img, prefix: str = "kartu"):
    date_folder = datetime.now().strftime("%Y-%m-%d")
    folder = os.path.join(config.BASE_OUTPUT, date_folder)
    ensure_dir(folder)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    filename = f"{timestamp}_{prefix}.jpg"
    path = os.path.join(folder, filename)
    ensure_dir(os.path.dirname(path))
    cv2.imwrite(path, img, [int(cv2.IMWRITE_JPEG_QUALITY), config.OUTPUT_QUALITY])
    return path


def save_collage(img, name: str = None):
    collages_folder = os.path.join(config.BASE_OUTPUT, "collages")
    ensure_dir(collages_folder)
    if name is None:
        name = datetime.now().strftime("summary_%Y-%m-%d.jpg")
    path = os.path.join(collages_folder, name)
    cv2.imwrite(path, img, [int(cv2.IMWRITE_JPEG_QUALITY), config.OUTPUT_QUALITY])
    return path
