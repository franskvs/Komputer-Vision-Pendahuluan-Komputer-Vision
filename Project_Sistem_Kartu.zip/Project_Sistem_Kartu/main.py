import os
import sys
from datetime import datetime

import cv2

import capture_module as capmod
import process_module as pm
import utils
import config


def process_image_file(path):
    img = capmod.load_image(path)
    img = pm.resize_standard(img)
    img = pm.adjust_brightness_contrast(img, alpha=1.0, beta=10)
    img = pm.add_watermark(img)
    img = pm.add_border(img)
    img = pm.add_timestamp(img)
    saved = utils.save_with_organization(img)
    print(f"Saved: {saved}")


def process_all_in_input():
    input_dir = config.INPUT_DIR
    if not os.path.isdir(input_dir):
        print(f"Input folder not found: {input_dir}")
        return
    files = [os.path.join(input_dir, f) for f in os.listdir(input_dir) if f.lower().endswith((".jpg", ".jpeg", ".png"))]
    for f in sorted(files):
        try:
            process_image_file(f)
        except Exception as e:
            print(f"Failed {f}: {e}")


def create_daily_collage():
    base = config.BASE_OUTPUT
    today = datetime.now().strftime("%Y-%m-%d")
    folder = os.path.join(base, today)
    if not os.path.isdir(folder):
        print("No images for today.")
        return
    files = [os.path.join(folder, f) for f in os.listdir(folder) if f.lower().endswith((".jpg", ".jpeg", ".png"))]
    files = sorted(files)[-4:]
    if len(files) < 4:
        print("Need at least 4 images to create collage. Found:", len(files))
        return
    imgs = [cv2.imread(p) for p in files]
    collage = pm.create_collage(imgs, title=f"DAILY SUMMARY: {today}")
    out = utils.save_collage(collage, name=f"summary_{today}.jpg")
    print(f"Collage saved: {out}")


def menu():
    while True:
        print("\nSmartAttend - Prototype")
        print("1. Process all images in input folder")
        print("2. Capture from webcam and process (bonus)")
        print("3. Create today's collage (4 latest images)")
        print("4. Exit")
        choice = input("Choice: ")
        if choice == "1":
            process_all_in_input()
        elif choice == "2":
            try:
                img = capmod.capture_from_webcam()
                if img is None:
                    print("Webcam capture cancelled.")
                    continue
                img = pm.resize_standard(img)
                img = pm.add_watermark(img)
                img = pm.add_border(img)
                img = pm.add_timestamp(img)
                saved = utils.save_with_organization(img, prefix="webcam")
                print(f"Saved webcam capture: {saved}")
            except Exception as e:
                print("Webcam capture failed:", e)
        elif choice == "3":
            create_daily_collage()
        elif choice == "4":
            break
        else:
            print("Invalid choice")


if __name__ == "__main__":
    menu()
