import cv2
import numpy as np
from datetime import datetime
import config


def resize_standard(img, width: int = None, height: int = None):
    if width is None:
        width = config.CARD_WIDTH
    if height is None:
        height = config.CARD_HEIGHT
    return cv2.resize(img, (width, height), interpolation=cv2.INTER_AREA)


def to_grayscale(img):
    return cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)


def adjust_brightness_contrast(img, alpha: float = 1.0, beta: int = 0):
    return cv2.convertScaleAbs(img, alpha=alpha, beta=beta)


def add_timestamp(img, text: str = None, position=None):
    if text is None:
        text = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    if position is None:
        position = (10, img.shape[0] - 10)
    cv2.putText(img, text, position, cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2, cv2.LINE_AA)
    return img


def add_border(img, border_size: int = 5, color=(0, 0, 0)):
    return cv2.copyMakeBorder(img, border_size, border_size, border_size, border_size, cv2.BORDER_CONSTANT, value=color)


def add_watermark(img, text: str = None, opacity: float = 0.4, position=None):
    if text is None:
        text = config.WATERMARK_TEXT
    overlay = img.copy()
    if position is None:
        position = (10, 30)
    cv2.putText(overlay, text, position, cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2, cv2.LINE_AA)
    cv2.addWeighted(overlay, opacity, img, 1 - opacity, 0, img)
    return img


def create_collage(img_list, title: str = None):
    imgs = [resize_standard(i) for i in img_list]

    def ensure_color(i):
        if len(i.shape) == 2:
            return cv2.cvtColor(i, cv2.COLOR_GRAY2BGR)
        return i

    imgs = [ensure_color(i) for i in imgs]
    row1 = np.hstack([imgs[0], imgs[1]])
    row2 = np.hstack([imgs[2], imgs[3]])
    collage = np.vstack([row1, row2])
    if title:
        top_h = 40
        canvas = np.ones((top_h, collage.shape[1], 3), dtype=np.uint8) * 220
        cv2.putText(canvas, title, (10, top_h - 12), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 0, 0), 2, cv2.LINE_AA)
        collage = np.vstack([canvas, collage])
    return collage
