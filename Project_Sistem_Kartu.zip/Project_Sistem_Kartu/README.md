# SmartAttend Card Capture Prototype

Prototype sistem capture kartu identitas untuk absensi.

## Struktur direktori
```
Project_Sistem_Kartu/
├── config.py
├── capture_module.py
├── process_module.py
├── utils.py
├── main.py
├── generate_samples.py
├── test_runner.py
├── requirements.txt
├── README.md
├── input/            # tempat meletakkan gambar input
└── output/           # folder hasil (terorganisir berdasarkan tanggal)
    ├── YYYY-MM-DD/
    └── collages/
```

## Instalasi
1. Pastikan Python 3.8+ terpasang.
2. Buat virtual environment (opsional):
   ```bash
   python -m venv venv
   venv\Scripts\activate  # Windows
   source venv/bin/activate # Linux/Mac
   ```
3. Install dependensi:
   ```bash
   pip install -r requirements.txt
   ```

## Menjalankan
- Untuk memproses semua gambar di folder `input`:
  ```bash
  python main.py
  # pilih menu 1 lalu enter
  ```

- Untuk mengambil foto lewat webcam (opsi bonus):
  ```bash
  python main.py
  # pilih menu 2, jendela preview muncul
  # tekan SPACE untuk menangkap, ESC untuk batal
  ```

- Untuk membuat collage dari 4 gambar terbaru hari ini:
  ```bash
  python main.py
  # pilih menu 3
  ```

- Opsi 4 untuk keluar.

## Contoh workflow
1. Letakkan 5 gambar kartu di `input/`.
2. Jalankan `python test_runner.py` untuk otomatis memproses dan membuat collage.
3. Lihat hasil di `output/<tanggal>/` dan `output/collages/`.

## Struktur kode
- `capture_module.py`: fungsi `load_image()` dan `capture_from_webcam()`
- `process_module.py`: fungsi resize, watermark, timestamp, dan collage
- `utils.py`: menyimpan file dengan organisasi folder
- `main.py`: menu CLI dan alur integrasi
- `generate_samples.py`: buat gambar dummy untuk testing
- `test_runner.py`: skrip tes otomatis

## Screenshot & Output
(Simpan gambar <5 screenshots> di folder root atau sertakan dalam report.)

## Packaging & Pengumpulan
1. Pastikan semua file sumber code, `README.md`, screenshot, dan video demo disiapkan.
2. Zip direktori `Project_Sistem_Kartu` menjadi:
   ```bash
   zip -r 12345678_NamaSaya_Project1.zip Project_Sistem_Kartu
   ```
   atau di Windows PowerShell:
   ```powershell
   Compress-Archive -Path Project_Sistem_Kartu -DestinationPath 12345678_NamaSaya_Project1.zip
   ```
3. Unggah file ZIP sesuai instruksi pengumpulan.

## Catatan
- Ini adalah versi awal; dapat ditingkatkan dengan GUI, deteksi orientasi, histogram equalization, dll.

---

Semoga membantu! 🚀